I write the results to the file (35/36/40.txt) since the text is large.
The program will print "done" to the console after finish.
Thanks~
### Exercises
# 35.3 transforms characters into their LEET counterparts.
python 35-3.py pride-and-prejudice.txt
# 36.4 learns to transform characters into their LEET counterparts.
python 36-4.py pride-and-prejudice.txt
### EXTRA CREDIT! (20 points!)
# 40.2 eliminates 2-letter words.
python 40-2.py pride-and-prejudice.txt
### EXTRA CREDIT! (10 points each)
### Redo up to 3 exercises
https://replit.com/@HsiaoTungL/CS253#Week9/README.md
# 17 X:Didn't print out the class's fields
javac Seventeen.java
java Seventeen ../pride-and-prejudice.txt
# 27 X:Didn't append new file to the result.
node TwentySeven.js ../pride-and-prejudice.txt
# 28 X:Didn't show the incremental word-count as the generator added words
javac TwentyEight.java
java TwentyEight ../pride-and-prejudice.txt