# README

Make sure you install all the dependencies, including numpy, keras, tensorflow.

For 35.py:

python 35.py pride-and-prejudice.txt

The leet counterpart of the whole book will be displayed in the console.

For 36.py:

python 36.py pride-and-prejudice.txt

Press "Enter" to transform the book to leets and the leet counterpart of the whole book will be displayed in the console.

I redid the week8 assignment: I delete the leet of 'u' since it does not have a one-to-one mapping.

https://replit.com/@JiSean/CS253-Assignmentsweek8#readme.md